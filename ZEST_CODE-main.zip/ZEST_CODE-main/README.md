# ZEST_CODE
This is the source code for our paper:  ZEST : A Zero-Shot Learning Framework for Unseen IoT Device Classification
